﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;

namespace ProgettoAdminReteFinal
{
    /// <summary>
    /// Class dedicated to handle export related events and export operations
    /// </summary>
    public partial class exportForm : Form
    {
        public exportForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Allow user to chose the folder where we are going to export
        /// </summary>
        private void bBrowse_Click(object sender, EventArgs e)
        {
            //if user selects a new folder, update the save path
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                this.tbSavePath.Text = folderBrowserDialog.SelectedPath;
            }
        }

        /// <summary>
        /// Export log, graphs and a csv file of values into the folder chosen by the user with the bBrowse_Click method, by default C:\
        /// and add the subfolder named \\export_day_month_year_hour_minute\\
        /// </summary>
        private void bExport_Click(object sender, EventArgs e)
        {
            //savepath -> "path to user selected folder(dafault C:\)"\export_day_month_year_hour_minute
            string _saveDirectoryPath = tbSavePath.Text + "\\export_" + DateTime.Now.Date.Day + "_" + DateTime.Now.Date.Month + "_" + DateTime.Now.Date.Year + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute;
            try
            {
                //check if directory already exist
                if (!Directory.Exists(_saveDirectoryPath))
                {
                    //if doesn't exist, create it!
                    Directory.CreateDirectory(_saveDirectoryPath);

                    //saving graphs as jpegs
                    Prog.mf.zgAcc.GraphPane.GetImage().Save(_saveDirectoryPath + "\\Acc.jpg", ImageFormat.Jpeg);
                    Prog.mf.zgGir.GraphPane.GetImage().Save(_saveDirectoryPath + "\\Gir.jpg", ImageFormat.Jpeg);
                    Prog.mf.zgMag.GraphPane.GetImage().Save(_saveDirectoryPath + "\\Mag.jpg", ImageFormat.Jpeg);
                    Prog.mf.agf.zgStdDev.GraphPane.GetImage().Save(_saveDirectoryPath + "\\AtdDev.jpg", ImageFormat.Jpeg);
                    Prog.mf.agf.zgXAxis.GraphPane.GetImage().Save(_saveDirectoryPath + "\\XAxis.jpg", ImageFormat.Jpeg);

                    using (StreamWriter sw = new StreamWriter(_saveDirectoryPath + "\\Log.txt", true))
                        sw.Write(Prog.mf.tbLog.Text);

                    //save path for the csv
                    string filePath = _saveDirectoryPath + "\\Values.csv";
                    //create values file
                    File.Create(filePath).Close();
                    //setting var that will be used to write values to file
                    List<string[]> _output = new List<string[]>();
                    //setting delimiter
                    string _delimiter = ";";

                    //inserting string arrays into the list
                    for (int k = 0; k < comHandler.nSensors; k++)
                    {
                        for (int i = 0; i < comHandler.rawAcc[0].Count(); i++)
                        {
                            _output.Add(new string[]{"acc",comHandler.rawAcc[k][i].X.ToString(),comHandler.rawAcc[k][i].Y.ToString(),comHandler.rawAcc[k][i].Z.ToString(),
                                                     "gyr",comHandler.rawGyr[k][i].X.ToString(),comHandler.rawGyr[k][i].Y.ToString(),comHandler.rawGyr[k][i].Z.ToString(),
                                                     "mag",comHandler.rawMag[k][i].X.ToString(),comHandler.rawMag[k][i].Y.ToString(),comHandler.rawMag[k][i].Z.ToString(),
                                                     Environment.NewLine});
                        }
                    }

                    int _l = _output.Count;

                    //writing output to file
                    using (System.IO.TextWriter writer = File.CreateText(filePath))
                    {
                        for (int index = 0; index < _l; index++)
                        {
                            writer.WriteLine(string.Join(_delimiter, _output[index]));
                        }
                    }

                    MessageBox.Show("Export completed", "Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    if (DialogResult.Yes == MessageBox.Show("Open export folder?", "", MessageBoxButtons.YesNo))
                    {
                        System.Diagnostics.Process.Start(_saveDirectoryPath);
                    }
                }
                else {
                    //if folder already exists
                    MessageBox.Show("Folder already existing, chose another folder", "failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                this.Close();
            }
            catch (Exception except)
            {
                MessageBox.Show("Failed to export : \r\n" + except.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        /// <summary>
        /// button cancel click event handler.
        /// </summary>
        private void bCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}